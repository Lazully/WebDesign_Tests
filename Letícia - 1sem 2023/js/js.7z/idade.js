var nome = prompt('Qual seu nome?');
var anoNascimento = prompt('Que ano você nasceu, ' + nome + '? ');
var data = new Date();
var ano = data.getFullYear();

idade = ano - anoNascimento;
alert('Ano atual: ' + ano);
alert('A sua idade é de: ' + idade);